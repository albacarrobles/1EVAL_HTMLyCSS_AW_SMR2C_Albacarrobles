## Ejercicio Pŕactico de Posicionamiento de Elementos

Curso desarrollado por [pekechis](http://github.com/pekechis) para [OpenWebinars](https://openwebinars.net/)
